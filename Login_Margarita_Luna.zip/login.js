const username = document.getElementById("username")
const password = document.getElementById("password")
const getInto = document.getElementById("getInto")

getInto.addEventListener ("click", (e)=> {
        e.preventDefault();
            if(password.value !== "" && username.value !== ""){
            window.location.href="home.html";
            }
           else if(password.value == "" && username.value == ""){
            alert("Ingresa tus datos")
           }            
        }
        )
        